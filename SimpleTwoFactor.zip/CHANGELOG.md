## [1.0.3](https://github.com/triopsi/SimpleTwoFactor/compare/v1.0.2...v1.0.3) (2025-02-26)


### Bug Fixes

* Always get the result SIMPLE_TWO_FA_NO_AUTH_REQUIREd ([f661db1](https://github.com/triopsi/SimpleTwoFactor/commit/f661db1c3a422bd6d18e324cf6fccaeba252533d))

## [1.0.2](https://github.com/triopsi/SimpleTwoFactor/compare/v1.0.1...v1.0.2) (2025-02-21)


### Bug Fixes

* remove coverage.xml ([18b258b](https://github.com/triopsi/SimpleTwoFactor/commit/18b258b130c75053f392542db689c999fdc3e90f))

## [1.0.1](https://github.com/triopsi/SimpleTwoFactor/compare/v1.0.0...v1.0.1) (2025-02-21)


### Bug Fixes

* semantic token ([e06c53a](https://github.com/triopsi/SimpleTwoFactor/commit/e06c53a3150b9a0c418345eca32a1d0af0857483))
* update example in readme ([df5f4ea](https://github.com/triopsi/SimpleTwoFactor/commit/df5f4ea93a320c7e6fea20f0d8460af13aca97a6))
* update zip ignore ([920f225](https://github.com/triopsi/SimpleTwoFactor/commit/920f2256eb6d6a1124349be3bdaa40d1994ba766))
* update zip ignore ([effd681](https://github.com/triopsi/SimpleTwoFactor/commit/effd681973d162014937a0c4f06b01a734d20238))

# 1.0.0 (2025-02-21)


### Features

* First init ([a2add87](https://github.com/triopsi/SimpleTwoFactor/commit/a2add877dea21f90212b6d72a38c34f2c86ceee0))
