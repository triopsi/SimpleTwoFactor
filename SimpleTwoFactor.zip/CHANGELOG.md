# 1.0.0 (2025-02-21)


### Features

* First init ([a2add87](https://github.com/triopsi/SimpleTwoFactor/commit/a2add877dea21f90212b6d72a38c34f2c86ceee0))
